package com.santram.voiceoperator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var languagePicker: Spinner
    private lateinit var listenButton: Button
    private var ttsReady = false

    private val languages = listOf("Hindi (India)", "English (India)")
    private val languageTags = listOf("hi-IN", "en-IN")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is not available on this device."
            listenButton.isEnabled = false
        } else {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        }
        requestMicPermissionIfNeeded()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF5F3EF.toInt())
        }

        val title = TextView(this).apply {
            text = "SANTRAM 9999999999999X"
            textSize = 23f
            setTextColor(0xFF171717.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "VOICE OPERATOR  •  ANDROID MVP V1"
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }

        languagePicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages)
        }

        listenButton = Button(this).apply {
            text = "🎙  TAP TO SPEAK"
            textSize = 18f
            setOnClickListener { startListening() }
        }

        status = TextView(this).apply {
            text = "Ready. Tap the microphone and speak."
            textSize = 15f
            setTextColor(0xFF245B39.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 14)
        }

        heard = TextView(this).apply {
            text = "Your recognized command will appear here."
            textSize = 16f
            setTextColor(0xFF222222.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 20, 12, 20)
        }

        val chatButton = Button(this).apply {
            text = "OPEN CHATGPT"
            setOnClickListener { openPackage("com.openai.chatgpt", "ChatGPT") }
        }
        val settingsButton = Button(this).apply {
            text = "ANDROID SETTINGS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "V1 works without an API key. It recognizes a tap-to-speak command, speaks a reply and opens approved apps. For open-ended AI tasks, continue in the ChatGPT app."
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(4, 22, 4, 0)
        }

        outer.addView(title, match())
        outer.addView(subtitle, match())
        outer.addView(languagePicker, match())
        outer.addView(listenButton, match())
        outer.addView(status, match())
        outer.addView(heard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        outer.addView(chatButton, match())
        outer.addView(settingsButton, match())
        outer.addView(note, match())
        setContentView(outer)
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun requestMicPermissionIfNeeded() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermissionIfNeeded()
            return
        }
        val r = recognizer ?: return
        val tag = languageTags[languagePicker.selectedItemPosition]
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        status.text = "Listening…"
        listenButton.isEnabled = false
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening. Speak now." }
        override fun onBeginningOfSpeech() { status.text = "Hearing your voice…" }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { status.text = "Processing speech…" }
        override fun onError(error: Int) {
            listenButton.isEnabled = true
            status.text = "Could not recognize speech. Please try again."
        }
        override fun onResults(results: Bundle?) {
            listenButton.isEnabled = true
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            heard.text = if (text.isBlank()) "No speech recognized." else "You said:\n$text"
            if (text.isNotBlank()) handleCommand(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT)
        when {
            hasAny(command, listOf("open whatsapp", "व्हाट्सएप खोलो", "व्हाट्सएप खोलें", "whatsapp kholo")) ->
                openPackage("com.whatsapp", "WhatsApp")
            hasAny(command, listOf("open youtube", "यूट्यूब खोलो", "youtube kholo")) ->
                openPackage("com.google.android.youtube", "YouTube")
            hasAny(command, listOf("open gmail", "जीमेल खोलो", "gmail kholo")) ->
                openPackage("com.google.android.gm", "Gmail")
            hasAny(command, listOf("open chrome", "क्रोम खोलो", "chrome kholo")) ->
                openPackage("com.android.chrome", "Chrome")
            hasAny(command, listOf("open chatgpt", "चैटजीपीटी खोलो", "chatgpt kholo")) ->
                openPackage("com.openai.chatgpt", "ChatGPT")
            hasAny(command, listOf("open settings", "सेटिंग खोलो", "सेटिंग्स खोलो", "settings kholo")) -> {
                speak("Opening Android settings")
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            hasAny(command, listOf("hello", "नमस्ते", "हेलो", "नमस्कार")) ->
                speak(if (languagePicker.selectedItemPosition == 0) "नमस्ते। SANTRAM वॉइस ऑपरेटर तैयार है।" else "Hello. SANTRAM Voice Operator is ready.")
            else -> {
                status.text = "For this AI request, open ChatGPT and speak your question there."
                speak(if (languagePicker.selectedItemPosition == 0) "इस काम के लिए ChatGPT खोलिए और अपना सवाल वहाँ बोलिए।" else "For this request, please continue in the ChatGPT app.")
            }
        }
    }

    private fun hasAny(text: String, keys: List<String>) = keys.any { text.contains(it) }

    private fun openPackage(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            status.text = "Opening $label…"
            speak("Opening $label")
            startActivity(launch)
        } else {
            status.text = "$label is not installed."
            speak("$label is not installed on this phone.")
        }
    }

    private fun speak(message: String) {
        status.text = message
        if (ttsReady) {
            val tag = languageTags.getOrElse(languagePicker.selectedItemPosition) { "en-IN" }
            tts?.language = Locale.forLanguageTag(tag)
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "santram-voice")
        }
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val tag = languageTags.getOrElse(languagePicker.selectedItemPosition) { "en-IN" }
            tts?.language = Locale.forLanguageTag(tag)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
